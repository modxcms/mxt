<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '7841440fd6ae74b58c3f0360f177f6a4',
      'native_key' => 'mxt',
      'filename' => 'modNamespace/cb4a0ec5ed192d7cdb92caa77c68fb08.vehicle',
      'namespace' => 'mxt',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15961f1717b0edf0a3ec1d3a057b66a0',
      'native_key' => 'mxt.theme',
      'filename' => 'modSystemSetting/35eb4c90fc00d12cc7d5e73fff60e7fd.vehicle',
      'namespace' => 'mxt',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8ccc39f4225fe67d57d2902b5a6484f',
      'native_key' => 'mxt.default_slogan',
      'filename' => 'modSystemSetting/c24d9cbd8c7d5f5008f6ff42d5e8433c.vehicle',
      'namespace' => 'mxt',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03dcc6fe1a1bc27cf46235afb4972846',
      'native_key' => 'mxt.default_copyright',
      'filename' => 'modSystemSetting/f22dd19850ffce20a55f8293b958cf83.vehicle',
      'namespace' => 'mxt',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eeb2d7dc3439c550e2b669451dc4c06f',
      'native_key' => 'mxt.default_theme_img',
      'filename' => 'modSystemSetting/f8d17a6900a897e4166e386913e19239.vehicle',
      'namespace' => 'mxt',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d05487007338a1fc2a40a591a84bf27',
      'native_key' => 'mxt.default_fposts',
      'filename' => 'modSystemSetting/e6e141298752e62927eb08ea907c47d5.vehicle',
      'namespace' => 'mxt',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ab40473b6cb91469405f3efc64fe7c0',
      'native_key' => 'mxt.default_carousel',
      'filename' => 'modSystemSetting/1a8688b602703ef0494402058980a45e.vehicle',
      'namespace' => 'mxt',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68a59a12f0ead73946d3d5bf4403e9ec',
      'native_key' => 'mxt.social_twitter',
      'filename' => 'modSystemSetting/3c54f333cb72438451d681f1e9ace32f.vehicle',
      'namespace' => 'mxt',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd555063736962867ae9297e16f45dd50',
      'native_key' => 'mxt.social_facebook',
      'filename' => 'modSystemSetting/aed8d3d1ffef0e4a92289b1bdc796feb.vehicle',
      'namespace' => 'mxt',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '672bd9d1f63e03d2cc2b97c731574567',
      'native_key' => NULL,
      'filename' => 'modCategory/15d31cb8b94de7a43b4a2c000515541e.vehicle',
      'namespace' => 'mxt',
    ),
  ),
);