<?php

$_lang['setting_mxt.theme'] = 'Theme Name';
$_lang['setting_mxt.theme_desc'] = 'Name od the theme to use';
$_lang['setting_mxt.default_slogan'] = 'Default Theme Slogan';
$_lang['setting_mxt.default_slogan_desc'] = '';
$_lang['setting_mxt.default_copyright'] = 'Default Theme Copyright';
$_lang['setting_mxt.default_copyright_desc'] = '';
$_lang['setting_mxt.default_theme_img'] = 'Default Theme Image';
$_lang['setting_mxt.default_theme_img_desc'] = '';
$_lang['setting_mxt.default_fposts'] = 'Default Featured Post IDs';
$_lang['setting_mxt.default_fposts_desc'] = '';
$_lang['setting_mxt.default_carousel'] = 'Default Carousel IDs';
$_lang['setting_mxt.default_carousel_desc'] = '';
$_lang['setting_mxt.social_twitter'] = 'Twitter';
$_lang['setting_mxt.social_twitter_desc'] = '';
$_lang['setting_mxt.social_facebook'] = 'Facebook';
$_lang['setting_mxt.social_facebook_desc'] = '';
