# MXT

Naming Conventions and elements to make interchangeable themes in MODX.
