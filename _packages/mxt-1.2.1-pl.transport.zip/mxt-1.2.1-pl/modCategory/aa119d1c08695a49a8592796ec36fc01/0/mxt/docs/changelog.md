# MXT 1.2.1
- Added Grid Layout Type